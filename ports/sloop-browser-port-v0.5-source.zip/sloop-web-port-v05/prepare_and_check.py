#!/usr/bin/env python3
"""Prepare SLOOP firmware source for the experimental Felucca web bridge.
No Emscripten required for generation / native syntax diagnostics.
"""
from pathlib import Path
import shutil, subprocess, sys
root = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    sys.exit('Usage: python3 prepare_and_check.py /path/to/sloop-fm1-main')
sloop = Path(sys.argv[1]).resolve()
if not (sloop / 'tests/hostsim.c').exists():
    sys.exit('Not a SLOOP source tree')
web = sloop / 'web/emu'
web.mkdir(parents=True, exist_ok=True)
for name in ('sloop_web.c', 'build.sh', 'index.html', 'worklet.js'):
    shutil.copy2(root / 'web/emu' / name, web / name)
shutil.copytree(root / 'web/emu/fonts', web / 'fonts', dirs_exist_ok=True)
# The Felucca browser bridge uses this power-on animation helper; SLOOP omits it.
compat = root / 'compat/fm1_led_anim.h'
if compat.exists():
    shutil.copy2(compat, sloop / 'firmware/hal/fm1_led_anim.h')
sys.path.insert(0, str(sloop / 'tools'))
import build
build.generate()
print('\nGenerated assets:')
for p in sorted((sloop / 'build/gen').glob('*.h')):
    print(' ', p.name, p.stat().st_size, 'bytes')
print('\nChecking native C compatibility:')
cmd = ['clang', '-std=gnu99', '-fsyntax-only', '-w', '-Ibuild/gen', '-Ifirmware/src', 'web/emu/sloop_web.c']
try:
    r = subprocess.run(cmd, cwd=sloop, text=True, capture_output=True)
except FileNotFoundError:
    sys.exit('clang not installed; generated headers are ready, syntax check skipped')
print((r.stdout + r.stderr).strip() or 'Native syntax check passed')
if r.returncode:
    print('\nBridge needs further adaptation before an Emscripten build can succeed.')
    sys.exit(r.returncode)
print('Next: run sh web/emu/build.sh with emcc installed.')
