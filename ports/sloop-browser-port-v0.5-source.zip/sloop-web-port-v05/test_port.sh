#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/tests
printf 'Checking native browser bridge syntax...\n'
clang -std=gnu99 -fsyntax-only -w -Ibuild/gen -Ifirmware/src web/emu/sloop_web.c
printf 'Compiling original SLOOP host DSP...\n'
clang -std=gnu99 -O1 -w -Ibuild/gen -Ifirmware/src tests/hostsim.c -lm -o build/tests/sloop_hostsim
printf 'Rendering original DSP audio...\n'
build/tests/sloop_hostsim 0 4 1 build/tests/sloop-engine-test.wav
python3 - <<'PY'
import wave
p='build/tests/sloop-engine-test.wav'
with wave.open(p) as w:
    assert w.getframerate()==44100 and w.getnchannels()==2 and w.getnframes()>44000
    print(f'PASS: {w.getnframes()} frames at {w.getframerate()} Hz, {w.getnchannels()} channels')
PY
if command -v emcc >/dev/null; then
  echo 'Emscripten found; attempting browser build...'
  sh web/emu/build.sh
else
  echo 'Browser WASM build SKIPPED: Emscripten (emcc) not installed.'
fi
