# SLOOP browser port: verified status

This is **not version 1.0** and is not yet a playable browser emulator.

## Verified in this build environment

- Felucca browser panel, AudioWorklet, and WASM bridge have been copied and adapted as a starting point.
- SLOOP-generated firmware headers are present in `build/gen/`.
- `clang -fsyntax-only` passes for `web/emu/sloop_web.c`.
- The unmodified SLOOP `tests/hostsim.c` compiles to a native executable and produces a valid 44.1-kHz stereo WAV.
- Run `./test_port.sh` to repeat the checks.

## Not yet verified

- Linking the full bridge with Emscripten, because `emcc` is unavailable in this environment.
- Correct boot, LCD output, audio playback, buttons, encoders, and persistent storage in the browser.
- Authentic 37-kit audition and all synthesis engines in the browser.

## Local next step

Install Emscripten SDK, activate its environment, and run:

```sh
./test_port.sh
python3 -m http.server 8080 -d build/emu
```

Then open http://localhost:8080. The server step only works after `emcc` successfully builds the WASM.

Do not publish this as a playable emulator until the browser smoke tests pass.

## Licensing

See `LICENSE` and `LICENSING.md` for upstream licensing and asset restrictions. Preserve attribution and verify distribution rights for all bundled assets before public hosting.
