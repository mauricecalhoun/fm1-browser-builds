# SLOOP browser compatibility test — v0.5

## Build

Install Emscripten and run `sh web/emu/build.sh` from the project root.
Serve `build/emu` over localhost or HTTPS:

```sh
cd build/emu
python3 -m http.server 8000
```

Open http://localhost:8000 in Safari, Chrome, Firefox, and Edge.

## Per-browser acceptance checklist

- [ ] Switch on succeeds and SLOOP screen draws
- [ ] Keyboard and on-screen buttons work
- [ ] Encoder changes are reflected in screen
- [ ] All 12 synth engines produce audio
- [ ] All 37 drum kits produce audio
- [ ] Transport, step sequencing, ratchets, and swing work
- [ ] Refresh and restore a saved pattern
- [ ] Mute/unmute and tab hide/restore recover audio
- [ ] No errors in developer console

Web MIDI is optional and is not required for passing browsers that lack it.

## Notes

This build intentionally requests 44.1 kHz, matching the SLOOP firmware.
If the browser cannot provide 44.1 kHz, startup fails with an explicit message
instead of playing at the wrong pitch. A future release can add a resampler.

The flash-storage namespace was changed from Felucca to SLOOP to avoid
mixing the two firmware images' persistent data. Older experimental SLOOP
sessions saved under the Felucca namespace will not be automatically imported.

No browser WASM build has been verified in the packaging environment.
