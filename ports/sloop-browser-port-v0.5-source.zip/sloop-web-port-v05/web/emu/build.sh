#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
[ -f build/gen/felucca_tables.h ] || { echo 'Generate headers first with python3 tools/build.py (generate step)'; exit 1; }
command -v emcc >/dev/null || { echo 'Install Emscripten first'; exit 1; }
mkdir -p build/emu/fonts
emcc -O2 -ffp-contract=off -std=gnu99 -w -Ibuild/gen -Ifirmware/src \
  --no-entry -sSTANDALONE_WASM -sSTACK_SIZE=1048576 -sINITIAL_MEMORY=33554432 \
  -sFILESYSTEM=0 -o build/emu/felucca.wasm web/emu/sloop_web.c
sed -e 's/@VERSION@/SLOOP-0.5/g' -e 's/@PREVIEW@/ (experimental)/g' web/emu/index.html > build/emu/index.html
cp web/emu/worklet.js build/emu/
cp web/emu/fonts/* build/emu/fonts/
